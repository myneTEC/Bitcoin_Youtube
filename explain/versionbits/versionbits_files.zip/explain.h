// Copyright (c) 2017-2019 myneTEC

include <mynetec>

#include "explain_preset.h"

hey guys and welcome back to our next video!

today i will explain the 2 files: versionbits.h and versionbits.cpp

same way i did it in the videos before in a most simplified way of grasping the overall picture for the specific files.
Its purpose, raw containments of declarations and functions etc....
to get us a better understanding of how mighty this bitcoin thing really is and the vast majority of files interacting with each other.
realising us in sum the perfect monetary and fully digitized Banking System for todays times for the Internet.

					i decided against my first idea following the code files starting from chainparamsbase
					to stay more in logic and walk through this code in what makes sense next.

					we reached the version* files in this process
					code line adding works quite well so it will stay!
					if you are interested into them. they are mostly placed above a specific code line!
					i still decided not walking through the implemented logic itself, as most of the functions are self explanatory
					and it would just blow the timings for those videos produced. a guy into this is not interested in wasting his time
					watching this stuff. and its even better if he learns understanding code logic on implemented functions by himself.
					its a learning process after all and cannot be learned by just watching videos alone cause you need to type code
					you need to programm this yourself to really grasp used logic terms in full.
					this can only be done by coding your own small little programms from scratch and work
					with the standard c++ libraries (as well as the one that boost ist offering).
					as well with your used IDE (compiler errors, runtime errors etc..) + general frustrating moments when stuck in code ;)


ok indroduction part done so lets not waste more of our precious time here and instead jump start right into this!!!











										     seems we reached the end of this video.

						        thx for watching have a powerful and nice day and till our next video ;)
										like or dislike and dont forget to hit the subscribe button!

													     BYE BYE *winks*





