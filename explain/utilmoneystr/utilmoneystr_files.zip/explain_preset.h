// Copyright (c) 2017-2019 myneTEC

include <mynetec>


-------------------------
utilmoneystr.h
-------------------------

short code file, just containing:

Preprocessor statements for marks (we are already used to them)

parse and Format Functions (line 17-19)

----------------------------
utilstrencodings.cpp
----------------------------

same here the file is implementing us the needed logic for those 3 functiones mentioned before:

FormatMoney function (line 14-33)

ParseMoney function (line 36-39)

ParseMoney function longer version (line 41-79)














