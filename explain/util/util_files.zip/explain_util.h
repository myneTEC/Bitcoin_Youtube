// Copyright (c) 2017-2019 myneTEC

include <mynetec>

#include "explain_preset.h"

hey guys and welcome back to our next video!

today i will explain the 2 files: util.h and util.cpp
same way i did it in the videos before in a most simplified way of grasping the overall picture for the specific files.
Its purpose, raw containments of declarations and functions etc....
to get us a better understanding of how mighty this bitcoin thing really is and the vast majority of files interacting with each other.
realising us in sum the perfect monetary and Banking System for todays times for the Internet.

for this i decided to build up a preset file with prewritten code as well. hence the including statement at the beginning ;)

		i will walk you through this thing step by step with marking its text with mouseOver events to save us some time
		for the typing part like i did with this file your reading at the given moment.

		i wasnt originally satisfied with all this typing, so i thought of cutting it out and instead switching to mouseOver events.
		it may not be perfect, but i think its an apple worth to bite into.
		developing those videos is a process after all. and like coding in the common programming language. new ideas coming a along the road
		and you experiment with this as well. so i thought giving it a try. cut out the talks, cut out typing.
		plain stupid mouse over markings and focus on what really counts. should make it also easier for people to follow the explanations.
		plus synchronises it better into the coders daily common work: "typing code". And this guy is not talking much he is mainly focusing on visual
		things and thinking about his routines he want to implement to get the thing running and working properly.
		so instead of doing a fancy yt video with lot of marketing talks and animations. i decided for a more simplistic way of doing things.

		Kiss Principiple: Keep It Stupid Simple!!!                (background music included ;) )


but lets not waste more of our precious time here and instead jump start right into this!!!



										seems we reached the end of this video.

						thx for watching have a powerful and nice day and till our next video ;)
										and dont forget to hit the subscribe button

													BYE BYE *winks*





