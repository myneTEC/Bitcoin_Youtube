// Copyright (c) 2017-2019 myneTEC

include <mynetec>

#include "explain_preset.h"

hey guys and welcome back to our next video!

today i will explain only 1 file: version.h

well if you did follow this video series from its beginning, you should be familiar right now with how things are explained to you.
the purpose, raw containments of declarations and functions etc....
i still wanna inform you that it is essentially meant for understanding of how mighty this bitcoin thing really is!
realising us in sum the perfect monetary and fully digitized Banking System for todays times for the Internet. And in a decentralised way :)


					we reached the version* files in this process

					i still decided not walking through the implemented logic itself, as most of the functions are self explanatory
					and it would just blow the time frames off for those videos produced.
					a guy into this is not interested in wasting his time either by	watching this stuff
					and its even better if he learns understanding code logic on implemented functions by himself.
					its a learning process after all and cannot be learned by just watching videos alone cause you need to type code
					you need to programm this yourself to really grasp used logic terms in full.
					this can only be done by coding your own small little programms from scratch
					and working with the standard c++ libraries (as well as the one that boost is offering).
					as well with your used IDE (compiler errors, runtime errors etc..) + general frustrating moments when stuck in code ;)


ok indroduction part done so lets not waste more of our precious time here and instead jump start right into this!!!











										     seems we reached the end of this video.

						        thx for watching have a powerful and nice day and till our next video ;)
										like or dislike and dont forget to hit the subscribe button!

													     BYE BYE *winks*





