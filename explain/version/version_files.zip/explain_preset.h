// Copyright (c) 2017-2019 myneTEC

include <mynetec>


-------------------------
version.h
-------------------------

just a short one!

containing:

PROTOCOL_VERSION
INIT_PROTO_VERSION
GETHEADERS_VERSION
MIN_PEER_PROTO_VERSION
CADDR_TIME_VERSION
NOBLKS_VERSION_START
NOBLKS_VERSION_END
BIP0031_VERSION
MEMPOOL_GD_VERSION
NO_BLOOM_VERSION
SENDHEADERS_VERSION

so just 11 of Integer Variables for storing the specific versioning numbers for specific things needed

man this really was a short file jeez.. *thumbsup*







