// Copyright (c) 2017-2019 myneTEC

include <mynetec>

#include "explain_preset.h"

hey guys and welcome back to our next video!

today i will explain the 2 files: utiltime.h and utiltime.cpp

same way i did it in the videos before in a most simplified way of grasping the overall picture for the specific files.
Its purpose, raw containments of declarations and functions etc....
to get us a better understanding of how mighty this bitcoin thing really is and the vast majority of files interacting with each other.
realising us in sum the perfect monetary and Banking System for todays times for the Internet.

i think the lines 11-14 will becoming an introduction part from here on that will stay hard coded and be with us through further code journey :)
		we could even put it into a function like for example: intro(){ eplanataoryLogic; }

the preset file was doing a good job in the last video, so i decided to keep it running.

the mouseOver marking was also not that bad of an idea, so it will as well stay with us :)

		i hope you enjoyed our last background music cause i decided to stay with this type of music a bit longer ;)
		otherwise just mute the video (you cannot always satisfy everyones needs and its more important to have your own things you like and styles
		than just blindfolded follow the ones from others isolated all the time)
		there is no further interest in talking about this in the comments. but you can send new insipirational music any time if you want to.


ok indroduction part done so lets not waste more of our precious time here and instead jump start right into this!!!











										     seems we reached the end of this video.

						        thx for watching have a powerful and nice day and till our next video ;)
										like or dislike and dont forget to hit the subscribe button!

													     BYE BYE *winks*





