// Copyright (c) 2017-2019 myneTEC Group all rights reserved.

include <mynetec>

#include "explain_preset.h"

hey guys and welcome back to our next video!

today i will explain 1 file: ui_interface.h

well if you did follow this video series from its beginning, you should be familiar right now with how things are explained to you.
the purpose, raw containments of declarations and functions etc....
i still wanna inform you that it is essentially meant for understanding of how mighty this bitcoin thing really is and capable of!

					we reached the ui_interface.h file in this process dealing with functionality for
					user interface.


					most of the functions are self explanatory

					the problem that comes here with going to much deep into
					for the logic will just blow this video in size. and from my own experience
					people prefer watching smaller over longer videos as well.
					But i strongly recommend using this video for inspiration and motivation for creating your very own thing with this Technology
					start getting more into code and download your very first IDE like Eclipse i am using here if you are completely new to all this
					you will soon get better in understanding the relationships for coding and becoming a better problem solver as well.
					i Just decided to give a bit of help for how to get a fast overview of this vast majority of code files bitcoin consists of
					to make it easier for simple minded guys and beginners in coding getting into this complex world of blockchain technology.
					and hopefully finding their own way with it.


ok indroduction part done so lets not waste more of our precious time here and instead jump start right into this!!!











										     seems we reached the end of this video.

						        thx for watching have a powerful and nice day and till our next video ;)
										like or dislike and dont forget to hit the subscribe button!

													     BYE BYE *winks*





